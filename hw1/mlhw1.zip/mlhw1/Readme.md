#
Readme for Machine Learning HW1 Coding Assignment
Required Environment:
	Python2
	Numpy

For the execution of code, simply use navigate to the folder and ./<respective_script_name>
Take Q15 for example , ./q15.py will execute PLA and print the information in console.
All output graphs are generated and saved in the same folder.

