#!/usr/bin/python
def test_func(array):
	array[0] = 1

array = [2,3,4]
test_func(array)
print array
